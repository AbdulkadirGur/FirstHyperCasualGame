
    

using System;
using UnityEngine;

    public class IgnoreGameUI : MonoBehaviour
    {
        private void Start()
        {
            
        }

        private void Update()
        {
            
        }
    }
